import datetime
from dataclasses import dataclass

from .base_payload import Payload


@dataclass
class RecordStart(Payload):
    workload: str
    sut_name: str
    duration: str
    apex_id: str

    @classmethod
    def parse(cls, raw_data: str) -> 'RecordStart':
        print(f"{raw_data=}")
        data = raw_data.split(',')
        print(f"{data=}")

        return cls(**{
            'duration': datetime.timedelta(minutes=int(data[1])),
            'workload': data[2],
            'sut_name': data[3],
            'apex_id': data[4],
        })

