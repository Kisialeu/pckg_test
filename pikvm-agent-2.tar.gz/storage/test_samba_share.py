import threading
import unittest
from unittest import mock

from .samba_share import SambaShare, SambaException
from .consts import MSG_ENV_VARS_NOT_FOUND

DUMMY_ENV_VARS = {
    "SMB_HOST": "smb://localhost",
    "SMB_PORT": "113",
    "SMB_SHARE": "samba_share",
    "SMB_USER": "user",
    "SMB_PASSWORD": "password"
}


class TestSambaShare(unittest.TestCase):
    @mock.patch('os.environ', {})
    def test_fails_if_env_vars_empty(self):
        storage = SambaShare()
        with self.assertRaises(SambaException) as ctx:
            storage.connect()
        self.assertTrue(MSG_ENV_VARS_NOT_FOUND in ctx.exception.args[0])

    @mock.patch('storage.SambaShare.upload')
    def test_successfully_manage_rlock(self, upload_mock):
        args_list = [[f'w{i}', f"s{i}", f"file{i}.txt"] for i in range(100)]
        storage = SambaShare()
        threads = [
            threading.Thread(target=storage, args=tuple(args_item))
            for args_item in args_list
        ]
        for thread in threads:
            thread.start()
            thread.join()

        calls = [mock.call(*c_args) for c_args in args_list]
        upload_mock.assert_has_calls(calls, any_order=True)
