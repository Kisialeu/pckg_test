import json
import logging
from dataclasses import dataclass
from typing import Optional

import jwt


@dataclass
class SambaSettings:
    host: str
    port: int
    share: str
    user: str
    password: str

    @classmethod
    def decode(cls, token: str, key: str) -> 'SambaSettings':
        payload = jwt.decode(token.encode(), key, algorithms=['HS256'])
        return cls(**payload)
