MSG_ENV_VARS_NOT_FOUND = "Environment variables a not set"
