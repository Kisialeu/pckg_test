import datetime

import jwt
import pytest
from storage import SambaSettings

SN = "1234567890"
HOST = "localhost"
PORT = 139
USER = "user"
PASS = "password"
SHARE = "sharename"
TS_NOW = datetime.datetime.now().timestamp()
KEY = f"{TS_NOW}{SN}"


@pytest.fixture
def token() -> str:
    payload = {
        "host": HOST,
        "port": PORT,
        "share": SHARE,
        "user": USER,
        "password": PASS
    }
    return str(jwt.encode(payload, KEY, algorithm='HS256'))


def test_successfully_untokenize_message(token):
    settings = SambaSettings.decode(token, KEY)
    assert settings.share == SHARE
    assert settings.host == HOST
    assert settings.port == PORT
    assert settings.user == USER
    assert settings.password == PASS
