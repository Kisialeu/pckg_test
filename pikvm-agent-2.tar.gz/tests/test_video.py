import asyncio
import datetime

from unittest import mock

import video


DUMMY_FILES = [
    'text_file.txt',
    'data_file.csv',
    'video_file.mkv',
]

TIMESTAMP = datetime.datetime.now().timestamp()


class StatObjMock(mock.MagicMock):
    def st_mtime(self, filename): # noqa
        return {filename: TIMESTAMP}


@mock.patch('os.listdir', return_value=DUMMY_FILES)
@mock.patch('os.stat', return_value=StatObjMock())
def test_successfully_return_video_files_only(list_mock, stat_mock): # noqa
    rec_list = asyncio.run(video.Record('').list())
    assert isinstance(rec_list, dict)
    assert len(rec_list) == 1


@mock.patch('os.listdir', return_value=())
def test_successfully_return_empty_dict_if_dir_empty(list_mock): # noqa
    rec_list = asyncio.run(video.Record('').list())
    assert isinstance(rec_list, dict)
    assert len(rec_list) == 0


@mock.patch('os.listdir', return_value=('text.txt'))
def test_successfully_return_empty_dict_if_video_not_exist(list_mock): # noqa
    rec_list = asyncio.run(video.Record('').list())
    assert isinstance(rec_list, dict)
    assert len(rec_list) == 0


@mock.patch('video.Record.list', return_value={'file.mkv': TIMESTAMP})
@mock.patch('os.remove')
def test_successfully_delete_video_file_if_exist(list_mock, clean_mock): # noqa
    asyncio.run(video.Record('path').clean())
    assert clean_mock.called_with('path/file.mkv')


@mock.patch('video.Record.clean')
def test_successfully_clean_files_before_start_recording(mock_clean):
    data = {'message': 'start-recording, 10'}
    asyncio.run(video.record_start(data))
    assert not video.queueRecord.empty()
    data = video.queueRecord.get()
    assert data['record']
    assert video.video_duration == datetime.timedelta(minutes=int(10))
    assert mock_clean.called


@mock.patch('websockets.connect')
@mock.patch('video.Record.list', return_value={'file.mkv': TIMESTAMP})
def test_successfully_stop_recording(list_mock, mock_conn): # noqa
    video.queueRecord.put({'message': 'record-stop'})
    server = 'localhost'
    sn = '0000'
    res = asyncio.run(video.record_stop(server, sn, None))
    mock_conn.assert_called_with(f"wss://{server}/ws/chat/{sn}/")
    assert res == "record_data,{0}".format({'file.mkv': TIMESTAMP})
    video.queueRecord.get()
