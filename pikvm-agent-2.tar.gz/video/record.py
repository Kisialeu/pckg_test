import os
from typing import Dict


class Record:
    def __init__(self, video_dir: str):
        self.video_dir = video_dir
        self.file_ext = 'mkv'

    def path(self, filename) -> str:
        return f"{self.video_dir}/{filename}"

    async def list(self) -> Dict[str, float]:
        """
        Return files from video_dir with file_ext extension
        :return: {filename: timestamp}
        """
        files_list = {}
        flt = filter(
            lambda filename: self.file_ext in filename,
            os.listdir(self.video_dir)
        )
        video_files = list(flt)
        for file in video_files:
            stat = os.stat(self.path(file))
            files_list[file] = stat.st_mtime
        return files_list

    async def clean(self):
        """
        Remove previous video file
        :return:
        """
        files = iter(await self.list())
        video_file = next(files, None)
        if video_file:
            os.remove(self.path(video_file))

    async def flush(self):
        files = await self.list()
        for file in files:
            os.remove(self.path(file))
