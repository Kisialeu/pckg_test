import json
import sys
import asyncio
import threading
import RPi.GPIO as GPIO
from queue import Queue
from time import sleep
import logging
import websockets
from w1thermsensor import W1ThermSensor, Unit, Sensor, errors
from storage import TemperatureStorage

t_log_queue = Queue(maxsize=5000)


async def temperatureSend(queue: Queue, log, pikvmServer, serialNumber):
    sensorData = {}
    while True:
        try:
            async with websockets.connect(
                    f'wss://{pikvmServer}/ws/chat/{serialNumber}/') as websocket:
                while True:
                    data = {}
                    if not queue.empty():
                        sensorData = queue.get(block=False, timeout=1)
                        log.info(f"queue: {sensorData}")
                        queue.task_done()
                    if len(sensorData) != 0:
                        for sensor in sensorData:
                            if 'name' in sensorData[sensor] and 'temp' in sensorData[sensor]:
                                data[sensorData[sensor]['name']] = sensorData[sensor]['temp']
                                t_log_queue.put({
                                    'temp': sensorData[sensor]['temp'],
                                    'name': sensorData[sensor]['name']
                                })
                        await websocket.send(json.dumps({"message": "temp_data", "temp_data": data}))
                    await asyncio.sleep(4.9)
        except websockets.exceptions.ConnectionClosedError:
            log.info("temperatureSend: got exception in sending metrics")
        except websockets.exceptions.InvalidStatusCode:
            log.info("temperatureSend: got InvalidStatusCode exception in sending metrics")
        except OSError:
            log.info("ws_receive: OSError")
        except Exception as ex:
            log.info(f'temperatureSend: [wide exception] {ex}')


def enumerateSensors(log):
    sensorPorts = {}
    ports = {
        17: 'port1',
        18: 'port2',
        0: 'port3',
        12: 'port4',
        13: 'port5',
        16: 'port6',
    }
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    log.info(ports)
    for port in ports.keys():
        GPIO.setup(port, GPIO.OUT)
        GPIO.output(port, GPIO.LOW)
    sleep(10)
    for port in ports.keys():
        log.info(f"Check sensor on {port}: {ports[port]}")
        for disablePort in ports.keys():
            if disablePort != port:
                GPIO.output(disablePort, GPIO.HIGH)
                sleep(0.1)
        GPIO.output(port, GPIO.LOW)
        sleep(3)
        for sensor in W1ThermSensor.get_available_sensors([Sensor.DS18B20]):
            try:
                if sensor.id not in sensorPorts.keys():
                    log.info(
                        f"Sensor {sensor.id} on {ports[port]} has temperature {sensor.get_temperature(Unit.DEGREES_C)}C"
                    )
                    if sensor.id in sensorPorts:
                        log.info('overlapping sensor ports. Restart.')
                        sys.exit(2)
                    sensorPorts[sensor.id] = {
                        'name': f"ds18b20-{ports[port]}",
                        'type': sensor.type.name
                    }
            except errors.SensorNotReadyError:
                pass
    for port in ports.keys():
        GPIO.output(port, GPIO.LOW)
        sleep(0.5)
    log.info("Check MAX31850 sensors")
    for sensor in W1ThermSensor.get_available_sensors([Sensor.MAX31850K]):
        try:
            if sensor.id not in sensorPorts.keys():
                log.info(
                    f"Sensor {sensor.id} has temperature {sensor.get_temperature(Unit.DEGREES_C)}C"
                )
                if sensor.id in sensorPorts:
                    log.info('overlapping sensor ports. Restart.')
                    sys.exit(2)
                sensorPorts[sensor.id] = {
                    'name': f'thermocouple-{sensor.id}',
                    'type': 'MAX31850K'
                }
        except errors.SensorNotReadyError:
            pass
    log.info(sensorPorts)
    return sensorPorts


async def write_temperature_log():
    t_storage = TemperatureStorage()
    while True:
        try:
            if not t_log_queue.empty():
                data = t_log_queue.get(block=True, timeout=1)
                t_storage.add(data['temp'], data['name'])
            await asyncio.sleep(1)
        except Exception as ex:
            logging.info('TEMP_LOG', ex)
