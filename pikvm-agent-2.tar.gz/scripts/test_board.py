#!/usr/bin/python3.10


import json
import logging
import os
import stat
import sys
import RPi.GPIO as GPIO
import requests
import w1thermsensor
from datetime import datetime
from systemd.journal import JournalHandler
from time import sleep
from w1thermsensor import W1ThermSensor, Unit, Sensor
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import board
import digitalio
import adafruit_max31865

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("board_self_test.log"),
        logging.StreamHandler()
    ]
)

logging.info(f'Self test starting. {datetime.now().strftime("%d/%m/%Y %H:%M:%S")}')


def KVMDAliveCheck():
    kvmdResponse = requests.get('https://localhost/api/info',
                                timeout=3,
                                verify=False)
    if kvmdResponse.status_code == 401:
        return True
    kvmdResponse.close()
    return False


sensorPorts = {}

while not KVMDAliveCheck():
    logging.info("kvmd service is down. sleep 10s.")
    sleep(10)

logging.info("kvmd check - OK")
ports = {
    17: 'port1',
    18: 'port2',
    0: 'port3',
    12: 'port4',
    13: 'port5',
    16: 'port6',
}
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
for port in ports.keys():
    GPIO.setup(port, GPIO.OUT)
    GPIO.output(port, GPIO.HIGH)
for port in ports.keys():
    for disablePort in ports.keys():
        if disablePort != port:
            GPIO.output(disablePort, GPIO.HIGH)
            sleep(0.2)
    GPIO.output(port, GPIO.LOW)
    sleep(3)
    sensors = W1ThermSensor.get_available_sensors([Sensor.DS18B20])
    successRead = False
    for sensor in sensors:
        if sensor.id not in sensorPorts.keys():
            try:
                logging.info(
                    f"{ports[port]} GPIO{port} Status OK, temp: {sensor.get_temperature(Unit.DEGREES_C)}C, {sensor.id}")
                successRead = True
                break
            except:
                pass
            if successRead:
                sensorPorts[sensor.id] = {
                    'name': ports[port]
                }
    if not successRead:
        logging.info(
            f"{ports[port]} GPIO{port} Status FAIL.")
for port in ports.keys():
    GPIO.output(port, GPIO.LOW)
    sleep(0.5)
for sensor in W1ThermSensor.get_available_sensors([Sensor.MAX31850K]):
    try:
        if sensor.id not in sensorPorts.keys():
            logging.info(
                f"MAX31850K sensor id {sensor.id} has temperature {sensor.get_temperature(Unit.DEGREES_C)}C"
            )
            if sensor.id in sensorPorts:
                logging.info('overlapping sensor ports. Restart.')
                sys.exit(2)
            sensorPorts[sensor.id] = {
                'name': 'thermocouple',
                'type': 'MAX31850K'
            }
    except w1thermsensor.errors.SensorNotReadyError:
        logging.error(f"MAX31850K sensor id {sensor.id} FAIL")
        pass

csPins = {
    'port1': digitalio.DigitalInOut(board.D22),
    'port2': digitalio.DigitalInOut(board.D25),
    'port3': digitalio.DigitalInOut(board.D1),
    'port4': digitalio.DigitalInOut(board.D5),
    'port5': digitalio.DigitalInOut(board.D6),
    'port6': digitalio.DigitalInOut(board.D26),
}
spi = board.SPI()
for port in csPins:
    cs = csPins[port]
    ptSensor = adafruit_max31865.MAX31865(
        spi,
        cs,
        wires=4,
        rtd_nominal=100.0,
        ref_resistor=400.0,
    )
    pt100temp = float(format(ptSensor.temperature, '.4f'))
    if pt100temp == -242.0200 or pt100temp > 200:
        logging.info(f"PT100 {port} temp read fail")
    else:
        logging.info(f"PT100 {port} temp: {pt100temp}")

# TODO: To show availability of the video input of the HDMI-CSI converter - if it's available - will send OK.
try:
    stat.S_ISLNK(os.lstat("/dev/kvmd-video").st_mode)
    logging.info("HDMI-CSI2 convertor availability - OK")
except FileNotFoundError:
    logging.error("HDMI-CSI2 convertor availability - FAIL")

# TODO: To switch on the Power ON and check the changing of a digital signal on the Power LED input after success -
#  to send OK and switch off the Power ON.
sess = requests.Session()
sess.post("https://127.0.0.1/api/auth/login",
          data={'user': 'admin', 'passwd': 'pXmvbc12vX8'},
          timeout=3,
          verify=False)

sleep(0.2)
sess.post("https://127.0.0.1/api/atx/click?button=power_long",
          timeout=3,
          verify=False)
power_state_response = sess.get("https://127.0.0.1/api/atx",
                                timeout=3,
                                verify=False)
power_state_json = json.loads(power_state_response.content)
sleep(1)
power_state_response = sess.get("https://127.0.0.1/api/atx",
                                timeout=3,
                                verify=False)
power_state_json = json.loads(power_state_response.content)
if not power_state_json['result']['leds']['power']:
    logging.info("Power LED - OK")
else:
    logging.error("Power LED - FAIL")
sess.post("https://127.0.0.1/api/atx/click?button=power_long",
          timeout=3,
          verify=False)
# TODO: To switch on the Power Reset and check the changing of a digital signal on the Power LED input after success -
#  to send OK and switch off the Power Reset.
sleep(8)
# # TODO: After successful points 3 and 4 to send Power LED - OK
resetPort = 27
GPIO.setup(resetPort, GPIO.OUT)
GPIO.output(resetPort, GPIO.HIGH)
sleep(1)
ledPort = 24
GPIO.setup(ledPort, GPIO.IN)
if GPIO.input(ledPort):
    logging.info("Reset LED - OK")
    GPIO.output(resetPort, GPIO.LOW)
else:
    GPIO.output(resetPort, GPIO.LOW)
    logging.error("Reset LED - FAIL")
logging.info(f'Self test done. {datetime.now().strftime("%d/%m/%Y %H:%M:%S")}')
