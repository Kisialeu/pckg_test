#How to use

copy `test_board.py` to raspberry pi with kvm image and run it `python test_board.py`  