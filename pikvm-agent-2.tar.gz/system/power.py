import os
import json
import time
import logging

import requests

POWER_ON = "https://127.0.0.1/api/atx/click?button=power"
POWER_OFF = "https://127.0.0.1/api/atx/click?button=power_long"


def get_session():
    sess = requests.Session()
    sess.post("https://127.0.0.1/api/auth/login",
              data={
                  'user': 'admin',
                  'passwd': os.environ['WEBUI_ADMIN_PASSWD']
              },
              timeout=3,
              verify=False)
    time.sleep(0.2)
    return sess


def _get_led_status(session: requests.Session):
    res = session.get('https://127.0.0.1/api/atx')
    try:
        res.raise_for_status()
    except requests.HTTPError:
        return None

    res = json.loads(res.text)
    if res['ok']:
        logging.warning(res)
        return res['result']['leds']['power']
    else:
        return None


async def power_status(status):
    session = get_session()
    try:
        led_status = _get_led_status(session)
        if (status and led_status) or led_status is None:
            logging.info('POWER ON')
            res = session.post(POWER_ON, timeout=3, verify=False)
            res.raise_for_status()

        elif not status and not led_status:
            logging.info("POWER_OFF")
            res = session.post(POWER_OFF, timeout=3, verify=False)
            res.raise_for_status()

        return True
    except requests.HTTPError:
        return False
