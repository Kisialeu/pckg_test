import argparse
import asyncio
import datetime
import json
import logging
import threading

import RPi.GPIO as GPIO
from queue import Queue
from threading import Thread
import w1thermsensor
from w1thermsensor import W1ThermSensor, Unit, Sensor
from systemd.journal import JournalHandler
import board
import digitalio
import adafruit_max31865
import websockets
from sensors import temperatureSend, enumerateSensors, write_temperature_log
from system import (
    getSN,
    getInterfacesInfo,
    healthCheck,
    registration,
    connect_sut,
    disconnect_sut,
    connect_sut_internal,
    restart_sut,
    power,
    sync_meta
)
from video import (
    record_start,
    record_stop,
    video_creator,
    screenshot,
    video_dir
)
from storage import SambaShare


log = logging.getLogger('demo')
log.addHandler(JournalHandler())
log.setLevel(logging.INFO)
try:
    W1ThermSensor()
except:
    log.info('Sensors not initialized')

parser = argparse.ArgumentParser()
parser.add_argument(
    '--server',
    help='Should be a valid server address ',
    default='amd-test.devteq.info'
)
args = parser.parse_args()
queue1 = Queue(maxsize=5000)
# videoQueue = Queue(maxsize=5000)

pikvmServer = args.server
serialNumber = getSN()
macAddress, ipv4address = getInterfacesInfo()
samba_storage = SambaShare(serialNumber)

connect_sut_internal()

pikmvInfo = {
    'sn': serialNumber,
    'mac': macAddress,
    'ipaddress': ipv4address,
}

WS_URI = f'wss://{pikvmServer}/ws/chat/{serialNumber}/'


async def checkIpAddress():
    while True:
        hwAddress, ipaddress = getInterfacesInfo()
        if ipaddress != pikmvInfo:
            pikmvInfo['ipaddress'] = ipaddress
        await sync_meta(pikvmServer, serialNumber, pikmvInfo, log)
        await asyncio.sleep(60)


async def getDSSensorTemp(sensorId):
    sensorClass = W1ThermSensor(Sensor.DS18B20, sensorId)
    while True:
        try:
            temperature = sensorClass.get_temperature(unit=Unit.DEGREES_C)
            sensorPorts[sensorId]['temp'] = temperature
        except w1thermsensor.errors.SensorNotReadyError:
            pass
        await asyncio.sleep(5)


async def getThermocoupleSensorTemp(sensorId):
    sensorClass = W1ThermSensor(Sensor.MAX31850K, sensorId)
    while True:
        try:
            temperature = sensorClass.get_temperature(unit=Unit.DEGREES_C)
            if temperature < 200.0:
                if sensorId not in sensorPorts:
                    sensorPorts[sensorId] = {
                        'name': f'thermocouple-{sensorId}',
                        'type': 'MAX31850K'
                    }
                sensorPorts[sensorId]['temp'] = temperature
            else:
                if sensorId in sensorPorts:
                    del sensorPorts[sensorId]
        except w1thermsensor.errors.SensorNotReadyError:
            pass
        await asyncio.sleep(5)


async def getPT1000SensorTemp():
    csPins = {
        'port1': digitalio.DigitalInOut(board.D22),
        'port2': digitalio.DigitalInOut(board.D25),
        'port3': digitalio.DigitalInOut(board.D1),
        'port4': digitalio.DigitalInOut(board.D5),
        'port5': digitalio.DigitalInOut(board.D6),
        'port6': digitalio.DigitalInOut(board.D26),
    }
    try:
        spi = board.SPI()
        while True:
            for port in csPins:
                cs = csPins[port]
                ptSensor = adafruit_max31865.MAX31865(
                    spi,
                    cs,
                    wires=4,
                    rtd_nominal=100.0,
                    ref_resistor=400.0,
                )
                ptSensor.auto_convert = True
                ptSensor.bias = True
                pt100temp = float(format(ptSensor.temperature, '.4f'))
                if pt100temp == -242.0200 or pt100temp > 200.0:
                    if port in sensorPorts:
                        del sensorPorts[port]
                else:
                    if port not in sensorPorts:
                        sensorPorts[port] = {}
                    sensorPorts[port]['name'] = f'pt100-{port}'
                    sensorPorts[port]['temp'] = pt100temp
            await asyncio.sleep(4)
    except OSError:
        log.info("spi not working")


async def populateQueue(queue):
    while True:
        queue.put(sensorPorts, False)
        await asyncio.sleep(4)


async def on_record_stop(message: str):
    """
    Record stop handler
    :param str message: "stop-recording,{workload},{status},{name}"
    :return:
    """
    file_name = await record_stop(
        pikvmServer,
        serialNumber,
        message
    )
    payload = message.split(',')
    sut_name = payload[-1]
    error = payload[-2]
    if error == 'True':
        workload_name = payload[-3]
        file_path = f"{video_dir}/{file_name}"
        samba_storage.prepare_for_upload(file_path, workload_name, sut_name)
        try:
            async with websockets.connect(WS_URI) as conn:
                payload = {
                    "message":  f"smb-credentials-req,{samba_storage.ts}"
                }
                await conn.send(json.dumps(payload))
        except Exception as ex:
            logging.log(logging.ERROR, f"{message}: {ex}")


async def on_samba_credentials_receive(message: str):
    payload = message.split(',')
    token = payload[1]
    upload_thread = threading.Thread(target=samba_storage, args=[token])
    upload_thread.start()
    upload_thread.join()


async def ws_receive():
    log.info("ws_receive started")
    while True:
        try:
            async with websockets.connect(WS_URI) as websocket:
                while True:
                        message = await websocket.recv()
                        message = json.loads(message)
                        if message['message'] == 'restart':
                            await restart_sut()
                            log.info("sut was restarted")
                        if message['message'] == 'power-off':
                            await power.power_status(False)
                        if message['message'] == 'power-on':
                            await power.power_status(True)
                        if message['message'] == 'disconnect':
                            await disconnect_sut()
                        if message['message'] == 'connect':
                            await connect_sut()
                        if message['message'] == 'screenshot':
                            await screenshot(pikvmServer, serialNumber)
                        if 'stop-recording' in message['message']:
                            await on_record_stop(message['message'])
                        if 'start-recording' in message['message']:
                            await record_start(message)
                        if 'smb-credentials' in message['message']:
                            await on_samba_credentials_receive(message['message'])
                        log.info(f"recv message: {message}")
        except websockets.exceptions.ConnectionClosedError:
            log.info("ws_receive: websockets.exceptions.ConnectionClosedError")
            await asyncio.sleep(1)
        except asyncio.exceptions.CancelledError:
            log.info("ws_receive: asyncio.exceptions.CancelledError")
            await asyncio.sleep(1)
        except asyncio.exceptions.TimeoutError:
            log.info("ws_receive: asyncio.exceptions.TimeoutError")
            await asyncio.sleep(1)
        except websockets.exceptions.InvalidStatusCode:
            log.info("ws_receive: websockets.exceptions.InvalidStatusCode")
            await asyncio.sleep(1)
        except ConnectionRefusedError:
            log.info("ws_receive: ConnectionRefusedError")
            await asyncio.sleep(1)
        except OSError as ex:
            log.error(f"ws_receive: OSError {ex.errno} {ex.strerror}")
            await asyncio.sleep(1)
        await asyncio.sleep(0.1)


def start_loop(secondLoop):
    asyncio.set_event_loop(secondLoop)
    secondLoop.run_forever()


def startWeb_loop(webLoop):
    asyncio.set_event_loop(webLoop)
    webLoop.run_forever()


def start_video_populate_loop(populate_loop):
    asyncio.set_event_loop(populate_loop)
    populate_loop.run_forever()


def start_ws_receive_loop(populate_loop):
    asyncio.set_event_loop(populate_loop)
    populate_loop.run_forever()


log.info(f"Starting: {json.dumps(pikmvInfo)}")

loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

loop.run_until_complete(registration(pikvmServer, serialNumber, pikmvInfo, log))

sensorPorts = enumerateSensors(log)

for sensor in sensorPorts:
    if sensorPorts[sensor]['type'] == 'DS18B20':
        loop.create_task(getDSSensorTemp(sensor))
    if sensorPorts[sensor]['type'] == 'MAX31850K':
        loop.create_task(getThermocoupleSensorTemp(sensor))
loop.create_task(getPT1000SensorTemp())

loop.create_task(populateQueue(queue1))
loop.create_task(checkIpAddress())
loop.create_task(healthCheck(pikvmServer, serialNumber, log))

try:
    threads = set()
    read_1_thread = asyncio.new_event_loop()
    read_1_thread.create_task(temperatureSend(queue1, log, pikvmServer, serialNumber))
    read_1_thread.create_task(write_temperature_log())
    threads.add(
        Thread(
            name="[THREAD][Temperature]",
            target=start_loop,
            args=(read_1_thread,)
        )
    )

    web_thread = asyncio.new_event_loop()
    web_thread.create_task(ws_receive())
    threads.add(
        Thread(
            name="[THREAD][Websockets]",
            target=startWeb_loop,
            args=(web_thread,)
        )
    )

    video_creator_t = asyncio.new_event_loop()
    video_creator_t.create_task(video_creator())
    threads.add(
        Thread(
            name="[THREAD][Video]",
            target=start_video_populate_loop,
            args=(video_creator_t,)
        )
    )

    for t in threads:
        t.start()

    loop.run_forever()
except KeyboardInterrupt:
    log.info('exit')
