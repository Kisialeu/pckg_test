from pystemd.systemd1 import Unit as pystemdUnit
import yaml
from aiohttp import web


async def titleChange(request):
    fileChanged = False
    jsonBody = await request.json()
    if 'title' not in jsonBody:
        return web.json_response({}, status=404, reason='title was not provided')
    with open("/etc/kvmd/meta.yaml", "w") as metaConfigFile:
        try:
            metaConfig = yaml.safe_load(metaConfigFile)
        except:
            metaConfig = None
        if metaConfig is not None:
            if 'server' in metaConfig:
                if 'host' in metaConfig['server']:
                    if metaConfig['server']['host'] != jsonBody['title']:
                        metaConfig['server']['host'] = jsonBody['title']
                        yaml.dump(metaConfig, metaConfigFile, default_flow_style=False, allow_unicode=True)
                        fileChanged = True
        else:
            yaml.dump(
                {
                    "server": {
                        "host": jsonBody['title']
                    }
                },
                metaConfigFile,
                default_flow_style=False,
                allow_unicode=True
            )
            fileChanged = True
    if fileChanged:
        kvmdUnit = pystemdUnit(b'kvmd.service')
        kvmdUnit.load()
        kvmdUnit.Unit.Restart('replace')
    return web.json_response({'title': jsonBody['title']}, status=200)


async def titleGet(request):
    title = "localhost"
    with open("/etc/kvmd/meta.yaml", "r") as metaConfigFile:
        metaConfig = yaml.safe_load(metaConfigFile)
        if metaConfig is not None:
            if 'server' in metaConfig:
                if 'host' in metaConfig['server']:
                    title = metaConfig['server']['host']
    return web.json_response({'title': title}, status=200)

