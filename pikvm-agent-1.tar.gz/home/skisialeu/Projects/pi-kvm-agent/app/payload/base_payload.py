class Payload:
    @classmethod
    def parse(cls, message: str) -> 'Payload':
        raise Exception('Not implemented')
