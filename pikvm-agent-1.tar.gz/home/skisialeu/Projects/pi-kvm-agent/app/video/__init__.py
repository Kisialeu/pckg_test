import io
import asyncio
import base64
import datetime
import json
from queue import Queue

import numpy
import pyvips as pyvips
import skvideo.io
import requests_unixsocket
import websockets
import logging
from PIL import Image

import payload
from .record import Record

SNAPSHOT_SOCKET = 'http+unix://%2Frun%2Fkvmd%2Fustreamer.sock/snapshot'
FRAME_WIDTH = 1920
FRAME_HEIGHT = 1080

queue_record = Queue(maxsize=1)
video_dir = '/var/lib/kvmd/msd'
video_duration = None
apex_id = None
session = requests_unixsocket.Session()


async def record_start(data):
    global video_duration
    global apex_id
    if queue_record.empty():
        await Record(video_dir).flush()
        record_data = {
            'record': True
        }
        message = data['message']
        start_payload = payload.RecordStart.parse(message)
        video_duration = start_payload.duration
        apex_id = start_payload.apex_id
        queue_record.put(record_data)


async def record_stop(pikvm_server, serial_number, message):
    if queue_record.empty():
        queue_record.put({
            'record': False
        })
    async with websockets.connect(
            f'wss://{pikvm_server}/ws/chat/{serial_number}/') as websocket:
        rec = Record(video_dir)
        file_dict = await rec.list()
        await websocket.send(
            json.dumps({
                "message": f"record_data,{file_dict}"
            })
        )
        keys = list(file_dict.keys())
        return keys[0] if keys else []


def create_writer(duration, apex_uuid):
    return skvideo.io.FFmpegWriter(
        f"{video_dir}/out_h264_%02d.mkv",
        inputdict={
            '-use_wallclock_as_timestamps': "1"
        },
        outputdict={
            '-vcodec': 'h264_omx',
            '-r': "12",
            '-f': 'segment',
            '-segment_time': f"{duration}",
            '-loglevel': 'debug',
            '-b:v': '2M',
            '-b:a': '192k',
            '-segment_list_size': '1',
            '-segment_wrap': '1',
            '-reset_timestamps': '1',
            '-metadata': f'ApexUUID={apex_uuid}'
        })


async def write_frame(writer):
    r = session.get(SNAPSHOT_SOCKET)
    if r.status_code == 200:
        image = Image.open(io.BytesIO(r.content))
        image = (
            numpy
            .array(image) # noqa
            .reshape(FRAME_HEIGHT, FRAME_WIDTH, 3) # noqa
        )
        try:
            writer.writeFrame(image)
        except AssertionError:
            logging.error(f"[ffmpeg_writer] Assert")
    else:
        r.close()


async def video_creator():
    global video_duration
    global apex_id

    recording = False
    ffmpeg_writer = None

    while True:
        try:
            if not queue_record.empty():
                data = queue_record.get()
                recording = data['record']
            if recording:
                if ffmpeg_writer is None:
                    ffmpeg_writer = create_writer(video_duration, apex_id)
                await write_frame(ffmpeg_writer)
                await asyncio.sleep(0.005)
            else:
                if ffmpeg_writer:
                    ffmpeg_writer.close()
                    await asyncio.sleep(1)
                    ffmpeg_writer = None
                await asyncio.sleep(1)
        except Exception as ex:
            if ffmpeg_writer:
                ffmpeg_writer.close()
                ffmpeg_writer = None
            logging.log(logging.ERROR, f"[VideoCreator], {ex} {type(ex)}")


async def screenshot(pikvmServer, serialNumber):
    r = session.get(SNAPSHOT_SOCKET)
    if r.status_code == 200:
        async with websockets.connect(
                f'wss://{pikvmServer}/ws/chat/{serialNumber}/') as websocket:
            await websocket.send(
                json.dumps(
                    {
                        "message": "screenshot-data",
                        "data": base64.b64encode(r.content).decode()
                    }
                )
            )
    r.close()
