import os
import random
import datetime
import threading

from datetime import timedelta


from .temperature import TemperatureStorage, FILENAME, TIME_FMT

SECONDS_IN_DAY = 24*60*60

storage = TemperatureStorage(debug=True)


def cleanup(file_path, delete_before=False):
    def decorator(fn):
        def wrapper(*args, **kwargs):
            if delete_before:
                if os.path.exists(file_path):
                    os.remove(file_path)
            fn(*args, **kwargs)
            if os.path.exists(file_path):
                os.remove(file_path)
        return wrapper
    return decorator


def create_days_interval(filename, days_count):
    f = open(filename, 'w')
    times = [
        (datetime.datetime.now().astimezone() - timedelta(days=days)).strftime(TIME_FMT)
        for days in range(days_count + 1)
    ]
    times.reverse()
    f.write(f'date, _value, port, port_location\n')
    for t in times:
        val = random.randint(0, 50)
        for i in range(int(SECONDS_IN_DAY/5)):
            f.write(f"{t}, {val}, port 1\n")
    f.close()


# @pytest.mark.skip()
@cleanup(file_path=storage.path, delete_before=True)
def test_create_file_if_not_exist():
    value = 22.7
    port = 'port1'
    storage.add(value, port)
    with open(f'./{FILENAME}', 'r') as f:
        lines = list(f.readlines())
    data = lines[1].split(',')
    data = [str(i).strip() for i in data]
    assert storage.title == lines[0]
    assert datetime.datetime.strptime(data[0], TIME_FMT)
    assert float(data[1]) == value
    assert data[2] == port


# @pytest.mark.skip()
@cleanup(storage.path)
def test_make_filo_if_more_than_30_days_in_file():
    value = 22.7
    port = 'port1'
    create_days_interval(storage.path, 31)
    thread = threading.Thread(target=storage.add, args=[value, port])
    thread.start()
    thread.join()
    with open(storage.path, 'r') as file:
        lines = list(file.readlines())

    oldest_date = lines[1].split(',')[0]
    oldest_date = datetime.datetime.strptime(oldest_date, TIME_FMT)
    td = datetime.datetime.now() - oldest_date
    assert td.days == 30

    data = lines[len(lines)-1].split(',')
    data = [str(i).strip() for i in data]
    d = datetime.datetime.strptime(data[0], TIME_FMT)
    assert (d - oldest_date).days == 30
    assert float(data[1]) == value
    assert data[2].replace('\n', '') == port
