import logging
import os
import datetime
import threading

DAYS_TO_STORE = 30
PATH = '/var/lib/kvmd/msd/'
FILENAME = 'temperature.csv'
TITLE_DATE = 'date'
TITLE_VALUE = '_value'
TITLE_PORT = 'port'
TITLE_ITEMS = [TITLE_DATE, TITLE_VALUE, TITLE_PORT]
TIME_FMT = '%Y-%m-%dT%H:%M:%S.%fZ'


class TemperatureStorage:
    def __init__(self, debug=False):
        if not debug:
            self.path = f'{PATH}/{FILENAME}'
            self.tmp_path = f'{PATH}/{FILENAME}.tmp'
        else:
            self.path = f'./{FILENAME}'
            self.tmp_path = f'./{FILENAME}.tmp'
        self.date_now = None
        self.days_limit = DAYS_TO_STORE
        self.lifo = False
        self.empty = False
        self.title = ','.join(TITLE_ITEMS) + '\n'
        self.lock = threading.RLock()

    def __call__(self, value, port):
        self.lock.acquire()
        try:
            self.add(value, port)
        except Exception as ex:
            logging.error(f"TemperatureStorage {ex}")
        self.lock.release()

    def add(self, value, port):
        self.date_now = datetime.datetime.now().astimezone()
        with self._open_or_create() as f:
            date = self.date_now.strftime(TIME_FMT)
            f.write(f'{date}, {value}, {port}\n')

    def _open_or_create(self):
        """
        Method to handle file creation, needs to insert title
        in new file, or handling lifo in existing file
        """
        is_new_file = not os.path.isfile(self.path)
        if is_new_file:
            new_file = open(self.path, 'a+')
            new_file.write(self.title)
            return new_file
        else:
            self._handle_lifo()
            return open(self.path, 'a')

    @staticmethod
    def _read_datetime(s):
        date_in_fmt = s.split(',')[0]
        date = datetime.datetime.strptime(date_in_fmt, TIME_FMT)
        return date

    def _is_more_than_limit(self, first_date):
        dt_naive = self.date_now.replace(tzinfo=None)
        td = abs(dt_naive - first_date)
        return td.days > self.days_limit

    def _fit_to_limit(self):
        """
        Remove oll rows with date more than limit.
        """
        def save_lines(line):
            if line.split(',')[0] == TITLE_DATE:
                # it is title
                return True
            return not self._is_more_than_limit(self._read_datetime(line))

        # Create tmp file with new files, instead to stora tmp data in RAM
        with open(self.path, 'r') as file:
            records_to_save = filter(save_lines, file.readlines())
            with open(self.tmp_path, 'w') as tmp_f:
                tmp_f.writelines(records_to_save)
        # Replace origin by tmp
        os.remove(self.path)
        os.rename(self.tmp_path, self.path)

    def _handle_lifo(self):
        """
        LIFO algorithm for file record set (last - in, first - out)
        """
        with open(self.path, 'r') as f:
            try:
                first_line = [next(f) for _ in range(2)]
                self.empty = False
                first_date = self._read_datetime(first_line[1])
                self.lifo = self._is_more_than_limit(first_date)
                self.empty = False
            except StopIteration:
                self.empty = True

        if self.lifo:
            self._fit_to_limit()
        elif self.empty:
            with open(self.path, 'w') as f:
                f.write(self.title)
