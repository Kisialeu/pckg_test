import socket
import logging
import threading
import datetime
from typing import List, Optional

from smb.SMBConnection import SMBConnection
from smb.base import SharedFile, SharedDevice
from smb import smb_constants
from .samba_settings import SambaSettings

# Default smb port
SMB_DEF_PORT = 139


class SambaException(Exception):
    pass


class SambaShare:
    def __init__(self, sn):
        self.lock = threading.RLock()
        self.sn = sn
        self.upload_timeout = 120
        self._conn = None
        self.settings: Optional[SambaSettings] = None
        self.file_path = None
        self.workload_name = None
        self.sut_name = None
        self.ts = None

    def _is_consistent(self):
        return all([
            self.settings,
            self.file_path,
            self.workload_name,
            self.sut_name
        ])

    def _check_share(self):
        """
        Compare share name with user's available shares
        :return: True if SMB_SHARE exist in share list, otherwise False
        """
        shares_list: List[SharedDevice] = self._conn.listShares()
        shares_names = [share.name for share in shares_list]
        return self.settings.share in shares_names

    def _is_remote_dir_exist(self, path: str, dir_name: str) -> bool:
        """
        Check is remote directory exist
        :param path: Path to directory search
        :param dir_name: Name of directory
        :return: True - exist, False - not exist
        """
        files: List[SharedFile] = self._conn.listPath(
            self.settings.share,
            path,
            search=smb_constants.SMB_FILE_ATTRIBUTE_DIRECTORY
        )
        res = filter(lambda file: file.filename == dir_name, files)
        return len(list(res)) > 0

    def _create_tree_if_not_exist(self, sut_name: str) -> str:
        """
        Create directory tree on samba share is not exist
        :param wl_name:
        :param sut_name:
        :return: constructed path
        """
        dt_now = datetime.datetime.now()
        path_items = [
            sut_name,
            str(dt_now.year),
            dt_now.strftime('%B'),  # month name
            str(dt_now.day)
        ]
        path = ''
        for directory in path_items:
            if not self._is_remote_dir_exist(path, directory):
                path = f"{path}/{directory}"
                self._conn.createDirectory(self.settings.share, path)
            else:
                path = f"{path}/{directory}"
        return path

    def connect(self):
        """
        Connect to samba host
        :return: None
        :raise: SambaException
        """
        if self._conn is None:
            self._conn = SMBConnection(
                self.settings.user,
                self.settings.password,
                socket.gethostname(),
                self.settings.share
            )
        if not self._conn.connect(self.settings.host, self.settings.port):
            self._conn.close()
            raise SambaException("Auth error")

    def disconnect(self):
        """
        Disconnect samba host
        :return: None
        """
        self._conn.close()
        logging.error("SAMBA closed")

    def _upload(self, wl_name: str, sut_name: str, file_path: str):
        """
        Protected upload smb function
        :param wl_name: workload name
        :param sut_name: sut name
        :param file_path: path to file on host
        :return: None
        :raise: SambaException
        """
        file_path_p = file_path.split('/')
        p_len = len(file_path_p)
        file_name = file_path_p[p_len - 1]
        path = self._create_tree_if_not_exist(sut_name)
        path = f"{path}/{file_name}"
        try:
            with open(file_path, 'rb') as file:
                self._conn.storeFile(
                    self.settings.share,
                    path,
                    file,
                    timeout=self.upload_timeout
                )
        except SambaException:
            raise SambaException(f"File to upload not found: {path}")

    def upload(self, token: str):
        """
        Public smb upload function
        :param str token: Tokenized samba settings
        :return: None
        """
        try:
            self.connect()
            self._upload(
                wl_name=self.workload_name,
                sut_name=self.sut_name,
                file_path=self.file_path
            )
        except SambaException as ex:
            logging.error(f"SAMBA: {ex}")
        # important! call disconnect anyway
        self.disconnect()
        self._conn = None

    def prepare_for_upload(
            self,
            file_path: str,
            wl_name: str,
            sut_name: str,
            upload_timeout=None
    ):
        self.ts = datetime.datetime.now().timestamp()
        self.file_path = file_path
        self.workload_name = wl_name
        self.sut_name = sut_name
        if upload_timeout:
            self.upload_timeout = upload_timeout

    def _untokenize_settings(self, token: str):
        key = f"{self.ts}{self.sn}"
        self.settings = SambaSettings.decode(token, key)

    def _clean(self):
        self.ts = None
        self.workload_name = None
        self.sut_name = None

    def __call__(self, token: str):
        """
        Function to call in thread
        :param str token: Tokenized samba settings
        :return:
        """
        self.lock.acquire()
        logging.error("SAMBA lock acquired")
        try:
            self._untokenize_settings(token)
            if self._is_consistent():
                logging.error(f"SAMBA Upload {self.file_path} start")
                self.upload(token)
                self._clean()
                logging.error(f"SAMBA Upload {self.file_path} finish")
            else:
                msg = f"SAMBA error: inconsistent state"
                logging.error(msg)
        except Exception as ex:
            logging.error(ex)
        self.lock.release()
        logging.error("SAMBA lock released")


