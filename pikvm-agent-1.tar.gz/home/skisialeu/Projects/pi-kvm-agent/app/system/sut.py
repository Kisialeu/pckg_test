import asyncio
import logging

import RPi.GPIO as GPIO
from aiohttp import web

USB_C_CTL_PIN = 16
RESET_CTL_PIN = 27


async def __pin_change_state(pin_num, status):
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(pin_num, GPIO.OUT)
    GPIO.output(pin_num, status)


async def __get_pin_state(pin):
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(pin, GPIO.OUT)
    return GPIO.input(pin)


def connect_sut_internal():
    __pin_change_state(USB_C_CTL_PIN, GPIO.HIGH)


async def connect_sut():
    await __pin_change_state(USB_C_CTL_PIN, GPIO.HIGH)
    return web.json_response({}, status=200)


async def disconnect_sut():
    await __pin_change_state(USB_C_CTL_PIN, GPIO.LOW)
    return web.json_response({}, status=200)


async def restart_sut():
    await __pin_change_state(RESET_CTL_PIN, GPIO.HIGH)
    await asyncio.sleep(0.5)
    await __pin_change_state(RESET_CTL_PIN, GPIO.LOW)


async def get_sut_state():
    try:
        return await __get_pin_state(USB_C_CTL_PIN)
    except Exception as ex:
        logging.error(ex)
        return None
