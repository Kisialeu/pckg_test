import json
import logging
import os
import re
import netifaces
import requests
from time import sleep
import websockets

from .power import power_status, get_session
from .sut import *


def getSN():
    if os.path.isfile("/proc/cpuinfo"):
        f = open('/proc/cpuinfo')
        for line in f.readlines():
            m = re.match(r"Serial.*\:\s+(?P<sn>.*)", line)
            if m is not None:
                f.close()
                return m.group('sn')
        f.close()
    return "undefined"


def KVMDAliveCheck():
    kvmdResponse = requests.get('https://localhost/api/info', timeout=3, verify=False)
    if kvmdResponse.status_code == 401:
        print("kvmd is alive.")
        return True
    kvmdResponse.close()
    return False


def getInterfacesInfo():
    defaultgw = netifaces.gateways()
    iface = defaultgw['default'][netifaces.AF_INET][-1]
    ifaddr = netifaces.ifaddresses(iface)
    mac = ifaddr[netifaces.AF_LINK][0]['addr']
    addr = ifaddr[netifaces.AF_INET][0]['addr']
    return mac, addr


async def sutStatus() -> int:
    try:
        sess = get_session()
    except Exception as ex:
        logging.error(ex)
        return 0
    sleep(0.2)
    try:
        resp = sess.get("https://127.0.0.1/api/atx",
                        timeout=3,
                        verify=False)
    except:
        return 0
    if resp.status_code == 200:
        resp_json = json.loads(resp.text)
        if not resp_json['result']['leds']['power']:
            return 1
    return 0


async def healthCheck(pikvmServer, serialNumber, log):
    while True:
        try:
            async with websockets.connect(
                    f'wss://{pikvmServer}/ws/chat/{serialNumber}/') as websocket:
                while True:
                    sut_status = await sutStatus()
                    sut_status = 'on' if sut_status else 'off'
                    interface_info = getInterfacesInfo()
                    await websocket.send(json.dumps({"message": f"ping,{sut_status},{interface_info[1]}"}))
                    await asyncio.sleep(20)
        except:
            pass


async def registration(pikvmServer, serialNumber, pikmvInfo, log):
    while not KVMDAliveCheck():
        sleep(1)
    async with websockets.connect(
            f'wss://{pikvmServer}/ws/chat/{serialNumber}/') as websocket:
        await websocket.send(json.dumps({"message": "register", "deviceInfo": pikmvInfo}))
        await websocket.close()


async def sync_meta(server, sn, info, log):
    try:
        uri = f'wss://{server}/ws/chat/{sn}/'
        async with websockets.connect(uri) as websocket:
            payload = {
                "message": "sync_meta",
                "ip": info["ipaddress"],
                "sn": sn,
                "hdmi": await get_sut_state()
            }
            await websocket.send(json.dumps(payload))
            await websocket.close()
    except Exception as ex:
        log.info(f"[sync_meta] {ex}")
